from odoo import api, fields, models, tools

class Audit(models.Model):
    _name = 'wb.audit'
    _description = 'Audit'

    asset_id = fields.Many2one(
        "wb.asset",
        required=True
    )

    audit_date = fields.Date()

    auditor = fields.Many2one(
        "hr.employee"
    )

    remarks = fields.Text()

    state = fields.Selection([
        ('draft', 'Draft'),
        ('verified', 'Verified')
    ], default='draft')