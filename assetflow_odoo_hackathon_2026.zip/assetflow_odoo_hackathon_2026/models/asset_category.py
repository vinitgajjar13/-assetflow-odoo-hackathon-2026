from odoo import fields, models, api

class AssetCategory(models.Model):
    _name = 'wb.asset.category'
    _description = 'Asset Category'
    _rec_name = "name"

    name = fields.Char(required=True)
    code = fields.Char()
    warranty_period = fields.Integer(
        string="Warranty (Months)"
    )
    description = fields.Text()
    active = fields.Boolean(default=True)

    asset_ids = fields.One2many(
        "wb.asset",
        "category_id",
        string="Assets"
    )