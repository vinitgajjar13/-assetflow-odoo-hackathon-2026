from odoo import models, fields, api

class Booking(models.Model):
    _name = 'wb.booking'
    _description = 'Booking'

    asset_id = fields.Many2one(
        "wb.asset",
        required=True
    )

    employee_id = fields.Many2one(
        "hr.employee"
    )

    start_datetime = fields.Datetime()

    end_datetime = fields.Datetime()

    purpose = fields.Text()

    state = fields.Selection([
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('done', 'Done'),
        ('cancel', 'Cancelled')
    ], default='draft')