from odoo import models, fields, api


class Department(models.Model):
    _name = 'wb.department'
    _description = 'assetflow_odoo_hackathon_2026.assetflow_odoo_hackathon_2026'

    name = fields.Char(string="Department Name", required=True)
    code = fields.Char(string="Department Code")
    manager_id = fields.Many2one(
        "hr.employee",
        string="Department Manager"
    )
    active = fields.Boolean(default=True)

    employee_ids = fields.One2many(
        "hr.employee",
        "department_id",
        string="Employees"
    )