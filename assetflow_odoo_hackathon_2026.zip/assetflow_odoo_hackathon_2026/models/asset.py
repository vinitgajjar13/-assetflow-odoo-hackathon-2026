from odoo import api, fields, models, tools

class Asset(models.Model):
    _name = 'wb.asset'
    _description = 'Asset'
    _rec_name = "name"

    name = fields.Char(required=True)
    asset_code = fields.Char(
        string="Asset Code",
        copy=False,
        readonly=True
    )
    serial_no = fields.Char()
    category_id = fields.Many2one(
        "wb.asset.category",
        string="Category"
    )

    employee_id = fields.Many2one(
        "hr.employee",
        string="Assigned Employee"
    )
    purchase_date = fields.Date()
    purchase_cost = fields.Float()
    status = fields.Selection([
        ('available', 'Available'),
        ('allocated', 'Allocated'),
        ('maintenance', 'Maintenance'),
        ('disposed', 'Disposed')
    ], default='available')

    image = fields.Image()
    note = fields.Text()