from odoo import fields, models, api

class maintenance(models.Model):
    _name = 'wb.maintenance'
    _description = 'wb.maintenance'

    asset_id = fields.Many2one(
        "wb.asset",
        required=True
    )

    issue = fields.Text()

    technician = fields.Char()

    maintenance_date = fields.Date()

    cost = fields.Float()

    state = fields.Selection([
        ('pending', 'Pending'),
        ('progress', 'In Progress'),
        ('done', 'Done')
    ], default='pending')