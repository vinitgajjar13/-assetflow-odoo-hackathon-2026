from odoo import fields, models, api

class AssetAllocation(models.Model):
    _name = 'wb.asset.allocation'
    _description = 'Asset Allocation'

    # name = fields.Char(required=True)
    asset_id = fields.Many2one(
        "wb.asset",
        required=True
    )

    employee_id = fields.Many2one(
        "hr.employee",
        required=True
    )

    allocation_date = fields.Date()

    expected_return_date = fields.Date()

    actual_return_date = fields.Date()

    state = fields.Selection([
        ('draft', 'Draft'),
        ('allocated', 'Allocated'),
        ('returned', 'Returned')
    ], default='draft')